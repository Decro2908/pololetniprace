import pygame
import random
import math

pygame.init()

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)

try:
    custom_font = pygame.font.Font('fat.ttf', 70)
    title_font = pygame.font.Font('fat.ttf', 100)
    button_font = pygame.font.Font('fat.ttf', 70)
except FileNotFoundError:
    print("Font file 'fat.ttf' not found.")
    pygame.quit()
    exit()

WIDTH, HEIGHT = 1400, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Zombie Land")

try:
    background_image = pygame.image.load('screen/bg.png')
    background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))
    scene_background = pygame.image.load('screen/s1.jfif')
    scene_background = pygame.transform.scale(scene_background, (WIDTH, HEIGHT))
except pygame.error as e:
    print(f"Error loading background image: {e}")
    pygame.quit()
    exit()

player_width, player_height = 120, 120
player_x, player_y = WIDTH // 2, HEIGHT - player_height
player_speed = 5
player_hp = 100
player_direction = 1  
try:
    player_image = pygame.image.load('Assets/hrac.png')
    player_image = pygame.transform.scale(player_image, (player_width, player_height))
except pygame.error as e:
    print(f"Error loading player image: {e}")
    pygame.quit()
    exit()

try:
    weapon_image = pygame.image.load('Assets/zbran.png')
    weapon_image = pygame.transform.scale(weapon_image, (80, 70))
except pygame.error as e:
    print(f"Error loading weapon image: {e}")
    pygame.quit()
    exit()

weapon_offset_y = 20
weapon_direction = 1  # Směr zbraně: 1 pro doprava, -1 pro doleva

try:
    zombie_image = pygame.image.load('Assets/zombie.png')
    zombie_image = pygame.transform.scale(zombie_image, (90, 85))
except pygame.error as e:
    print(f"Error loading zombie image: {e}")
    pygame.quit()
    exit()

zombie_speed = 1
zombies = []

bullets = []
bullet_speed = 10
bullet_color = RED
bullet_radius = 5

wave = 1
wave_timer = 0
wave_duration = 20 * 1000 

FPS = 60
clock = pygame.time.Clock()

def draw_text(text, font, color, x, y):
    text_obj = font.render(text, True, color)
    text_rect = text_obj.get_rect(center=(x, y))
    screen.blit(text_obj, text_rect)

def draw_transparent_button(x, y, width, height, text, font, base_color, hover_color, alpha=150):
    mouse_pos = pygame.mouse.get_pos()
    button_rect = pygame.Rect(x, y, width, height)
    
    button_surface = pygame.Surface((width, height), pygame.SRCALPHA)
    
    if button_rect.collidepoint(mouse_pos):
        button_surface.fill((*hover_color, alpha))
    else:
        button_surface.fill((*base_color, alpha))
    
    screen.blit(button_surface, (x, y))
    
    draw_text(text, font, WHITE, x + width // 2, y + height // 2)

    return button_rect

def main_menu():
    menu_running = True
    while menu_running:
        screen.blit(background_image, (0, 0))
        
        start_button = draw_transparent_button(WIDTH // 2 - 100, HEIGHT // 2, 200, 50, 'Start', button_font, (0, 0, 0), (255, 0, 0), alpha=100)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                menu_running = False
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if start_button.collidepoint(event.pos):
                    menu_running = False

        pygame.display.flip()
        clock.tick(FPS)

def spawn_zombie():
    zombie_x = random.randint(0, WIDTH - 90)
    zombie_y = random.randint(-100, -40)
    zombies.append([zombie_x, zombie_y])

def draw_hp_bar(x, y, hp, max_hp):
    bar_width = 200
    bar_height = 20
    fill_width = int((hp / max_hp) * bar_width)
    pygame.draw.rect(screen, RED, (x, y, bar_width, bar_height))
    pygame.draw.rect(screen, GREEN, (x, y, fill_width, bar_height))

def game_loop():
    global player_x, player_y, player_hp, wave, wave_timer, zombie_speed, weapon_direction, player_direction

    running = True
    start_time = pygame.time.get_ticks()

    while running:
        screen.blit(scene_background, (0, 0))

        current_time = pygame.time.get_ticks()
        if current_time - start_time >= wave_duration:
            wave += 1
            zombie_speed += 0.5
            start_time = current_time

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1: 
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    angle = math.atan2(mouse_y - (player_y + weapon_offset_y), mouse_x - (player_x + player_width // 2))
                    bullet_dx = math.cos(angle) * bullet_speed
                    bullet_dy = math.sin(angle) * bullet_speed
                    bullets.append([player_x + player_width // 2, player_y + weapon_offset_y, bullet_dx, bullet_dy])

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT] and player_x > 0:
            player_x -= player_speed
            player_direction = 1 
        if keys[pygame.K_RIGHT] and player_x < WIDTH - player_width:
            player_x += player_speed
            player_direction = -1  

        if keys[pygame.K_LEFT]:
            weapon_direction = 1  
        if keys[pygame.K_RIGHT]:
            weapon_direction = -1  
        
        if weapon_direction == -1:
            weapon_offset_x = -10 
        else:
            weapon_offset_x = 70  
        
        if player_direction == -1:
            flipped_player_image = pygame.transform.flip(player_image, True, False)
            screen.blit(flipped_player_image, (player_x, player_y))
        else:
            screen.blit(player_image, (player_x, player_y))

        for bullet in bullets[:]:
            bullet[0] += bullet[2]
            bullet[1] += bullet[3]
            if bullet[0] < 0 or bullet[0] > WIDTH or bullet[1] < 0 or bullet[1] > HEIGHT:
                bullets.remove(bullet)

        if random.randint(1, 50) == 1:
            spawn_zombie()

        for zombie in zombies[:]:
            angle = math.atan2(player_y - zombie[1], player_x - zombie[0])
            zombie_dx = math.cos(angle) * zombie_speed
            zombie_dy = math.sin(angle) * zombie_speed
            zombie[0] += zombie_dx
            zombie[1] += zombie_dy

            distance = math.sqrt((zombie[0] - player_x) ** 2 + (zombie[1] - player_y) ** 2)
            if distance < 60:
                zombies.remove(zombie)
                player_hp -= 15
                if player_hp <= 0:
                    print("Game Over")
                    running = False

        for bullet in bullets[:]:
            for zombie in zombies[:]:
                distance = math.sqrt((bullet[0] - (zombie[0] + 45)) ** 2 + (bullet[1] - (zombie[1] + 42)) ** 2)
                if distance < bullet_radius + 45:
                    bullets.remove(bullet)
                    zombies.remove(zombie)
                    break

        if weapon_direction == -1:
            flipped_weapon_image = pygame.transform.flip(weapon_image, True, False)
            screen.blit(flipped_weapon_image, (player_x + player_width // 2 - weapon_offset_x, player_y + weapon_offset_y))  # Otočení zbraně
        else:
            screen.blit(weapon_image, (player_x + player_width // 2 - weapon_offset_x, player_y + weapon_offset_y))  # Posunutí zbraně doprava

        for bullet in bullets:
            pygame.draw.circle(screen, bullet_color, (int(bullet[0]), int(bullet[1])), bullet_radius)

        for zombie in zombies:
            screen.blit(zombie_image, (zombie[0], zombie[1]))

        draw_hp_bar(10, 10, player_hp, 100)
        draw_text(f"Vlna {wave}", custom_font, WHITE, WIDTH // 2, 50)

        pygame.display.flip()
        clock.tick(FPS)

if __name__ == "__main__":
    main_menu()
    game_loop()
    pygame.quit()
    exit()
